import gc
import os
import time

from media.sensor import *
from media.media import *


FRAME_W = ALIGN_UP(320, 16)
FRAME_H = 240
CAPTURE_CHN = CAM_CHN_ID_2


def main():
    sensor = None
    saved = False
    try:
        sensor = Sensor()
        sensor.reset()
        sensor.set_framesize(width=800, height=480)
        sensor.set_pixformat(Sensor.YUV420SP)
        sensor.set_framesize(width=FRAME_W, height=FRAME_H, chn=CAPTURE_CHN)
        sensor.set_pixformat(Sensor.RGB565, chn=CAPTURE_CHN)
        MediaManager.init()
        sensor.run()
        for _ in range(15):
            sensor.snapshot(chn=CAPTURE_CHN)
            time.sleep_ms(10)

        img = sensor.snapshot(chn=CAPTURE_CHN)
        print("$CAPTURE,size=%dx%d" % (FRAME_W, FRAME_H))
        for path in (
            "/sdcard/k230_capture.jpg",
            "/data/k230_capture.jpg",
            "/flash/k230_capture.jpg",
            "k230_capture.jpg",
        ):
            try:
                img.save(path)
                print("$CAPTURE_SAVED,%s" % path)
                saved = True
                break
            except Exception as exc:
                print("$CAPTURE_SAVE_FAIL,%s,%s" % (path, exc))

        if not saved:
            print("$CAPTURE_IMG_DIR,%s" % ",".join(dir(img)))

        img = None
        gc.collect()
    finally:
        try:
            if sensor:
                sensor.stop()
        except Exception as exc:
            print("$CAPTURE_STOP_FAIL,%s" % exc)
        try:
            MediaManager.deinit()
        except Exception as exc:
            print("$CAPTURE_MEDIA_DEINIT_FAIL,%s" % exc)


main()
